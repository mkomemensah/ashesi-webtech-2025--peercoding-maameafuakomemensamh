<?php
session_start();
require_once 'db_helper.php';

$message = '';
$error = '';

// Check if the form was submitted using POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Server-side validation—
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';
    
    // Simple validation checks
    if (empty($username) || empty($password) || empty($role)) {
        $error = "All fields are required!";
    } elseif (strlen($password) < 6) {
        // Minimum password length check 
        $error = "Password must be at least 6 characters long.";
    } elseif (!in_array($role, ['student', 'faculty'])) {
        $error = "Invalid role selected.";
    } else {
        // 1.a: Check if username is already taken
        if (find_user_by_username($username)) {
            $error = "Oops! That username is already taken. Try another one.";
        } else {
            // Create the user and hash the password 
            if (create_user($username, $password, $role)) {
                $message = "Success! Your account has been created. You can now <a href='login.php' style='color: white; text-decoration: underline;'>log in</a>.";
                // Clear inputs on success
                unset($username, $password, $role);
            } else {
                $error = "Something went wrong while saving your data. Try again!";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>SmartRegister – Register</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <nav>
    <div class="logo">SmartRegister</div>
    <div class="nav-links">
      <a href="login.php">Login</a>
    </div>
  </nav>

  <main>
    <h1 class="dashboard-title">Join SmartRegister!</h1>
    
    <section class="form-section" style="max-width: 400px; margin: 2rem auto; padding: 1.5rem; background: #f0f0f0; border-radius: 10px;">
      
      <?php if ($message): ?>
        <p style="color: white; background-color: green; padding: 0.75rem; border-radius: 5px; margin-bottom: 1rem; text-align: center; font-weight: bold;"><?php echo $message; ?></p>
      <?php endif; ?>
      <?php if ($error): ?>
        <p style="color: white; background-color: red; padding: 0.75rem; border-radius: 5px; margin-bottom: 1rem; text-align: center; font-weight: bold;"><?php echo $error; ?></p>
      <?php endif; ?>
      

      <form action="register.php" method="POST">
        <label for="username" style="font-weight: bold;">Choose a Username:</label><br>
        <input type="text" id="username" name="username" required value="<?php echo htmlspecialchars($username ?? ''); ?>"
               style="width: 100%; padding: 0.5rem; margin-bottom: 1rem; border: 1px solid #ccc; border-radius: 5px;"><br>

        <label for="password" style="font-weight: bold;">Password (min 6 chars):</label><br>
        <input type="password" id="password" name="password" required minlength="6"
               style="width: 100%; padding: 0.5rem; margin-bottom: 1rem; border: 1px solid #ccc; border-radius: 5px;"><br>
        
        <label for="role" style="font-weight: bold;">Your Role:</label><br>
        <select id="role" name="role" required 
                style="width: 100%; padding: 0.5rem; margin-bottom: 1.5rem; border: 1px solid #ccc; border-radius: 5px;">
            <option value="">-- Select One --</option>
            <option value="student" <?php echo (($role ?? '') === 'student') ? 'selected' : ''; ?>>Student</option>
            <option value="faculty" <?php echo (($role ?? '') === 'faculty') ? 'selected' : ''; ?>>Faculty</option>
        </select><br>

        <button type="submit" style="width: 100%; background-color: #2b6cb0; color: white; border: none; padding: 0.75rem; border-radius: 5px; cursor: pointer;">
          Register
        </button>
      </form>
      <p style="margin-top: 1rem; text-align: center;">Already have an account? <a href="login.php" style="color: #2b6cb0; text-decoration: none; font-weight: bold;">Log In</a></p>
    </section>
  </main>
</body>
</html>