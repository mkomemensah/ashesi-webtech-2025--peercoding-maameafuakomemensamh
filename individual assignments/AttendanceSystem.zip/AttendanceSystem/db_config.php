<?php
// connecting to our real database on myphpadmin. For some reason I cant find the web tech one that we created but i have a database called test there

define('DB_HOST', 'localhost'); /
define('DB_NAME', 'test');     // The database I  have
define('DB_USER', 'root'); // <-- Change this (often 'root')
define('DB_PASS', ''); // 

// I made a function to connect, so I don't repeat this code everywhere
function db_connect() {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $options = [
        // This makes sure PDO throws a proper exception when things go wrong
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, 
        // This sets the default fetch mode to associative arrays 
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        // Time to connect to the database 
        return new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (\PDOException $e) {
        // If it fails, stop everything and show the error.
        // It's a connection error, so I'll just show a generic message to the user.
        die("Connection failed: " . $e->getMessage()); 
    }
}
?>