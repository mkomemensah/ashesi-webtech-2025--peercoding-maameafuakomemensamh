<?php
// Let's start the session
session_start();

// Clear out everything from the session
$_SESSION = array();

// If a session cookie exists, destroy it too (secure logout)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Finally, destroy the session itself
session_destroy();

// Redirect the user back to the login page!
header("Location: login.php");
exit;
?>