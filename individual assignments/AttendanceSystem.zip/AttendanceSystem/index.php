<?php
  //  start the session right away to check if the user is logged in.
  session_start();
  require_once 'db_helper.php';
  
  //  If no one is logged in, redirect them to the login page.
  if (!isset($_SESSION['user_id'])) {
      header('Location: login.php');
      exit; // Stop executing this script!
  }

  // Grab user details from the session
  $userId = $_SESSION['user_id'];
  $username = $_SESSION['username'];
  $role = $_SESSION['role'];
  
  // -----------------------------------------------------
  // Handle POST requests for different dashboard actions
  // -----------------------------------------------------
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 2.a: Faculty Course Creation Logic
    if ($role === 'faculty' && isset($_POST['action']) && $_POST['action'] === 'create_course') {
        // 4.b: Server-side validation for course creation
        $courseName = trim($_POST['courseName'] ?? '');
        $description = trim($_POST['description'] ?? '');

        if (empty($courseName) || empty($description)) {
            $course_message = "Course name and description are required!";
            $course_error = true;
        } else {
            if (create_course($courseName, $description, $userId)) {
                $course_message = "Awesome! Course **'{$courseName}'** has been created.";
            } else {
                $course_message = "Hmm, couldn't save the course. Try again.";
                $course_error = true;
            }
        }
    }

    // 2.b: Faculty Request Management Logic (Approve/Reject)
    if ($role === 'faculty' && isset($_POST['action']) && in_array($_POST['action'], ['approve', 'reject'])) {
        $course_id = $_POST['course_id'] ?? '';
        $student_id = $_POST['student_id'] ?? '';
        $request_action = $_POST['action'];

        if (process_request($course_id, $student_id, $request_action)) {
            $request_message = "Request for Course ID {$course_id} was successfully **{$request_action}d**!";
        } else {
            $request_message = "Error processing request, maybe it was already handled?";
            $request_error = true;
        }
    }

    // 3.a: Student Join Course Request Logic
    if ($role === 'student' && isset($_POST['action']) && $_POST['action'] === 'join_course') {
        $course_id = $_POST['course_id'] ?? '';

        if (create_join_request($course_id, $userId)) {
            $join_message = "Request sent! Waiting for faculty approval. Good luck!";
        } else {
            $join_message = "You have already requested or are enrolled in this course. Chill out!";
            $join_error = true;
        }
    }
  }


  // I used PHP variables here so I can reuse them for other pages easily
  $pageTitle = "SmartRegister – " . ucfirst($role) . " Dashboard";
  $headerTitle = ucfirst($role) . " Dashboard: Welcome, " . htmlspecialchars($username) . "!";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo $pageTitle; ?></title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <nav>
    <div class="logo">SmartRegister</div>
    <div class="nav-links">
      <a href="index.php">Dashboard</a>
      <a href="logout.php">Logout</a>
    </div>
  </nav>

  <main>
    <h1 class="dashboard-title"><?php echo $headerTitle; ?></h1>
    
    <p style="text-align: center; margin-bottom: 2rem;">You are logged in as a **<?php echo strtoupper($role); ?>**.</p>

    <?php if ($role === 'faculty'): ?>
      
      <h2 style="text-align: center; color: #2b6cb0; margin-bottom: 1rem;">Manage Courses and Requests</h2>
      
      <?php if (isset($course_message)): ?>
          <p style="color: white; background-color: <?php echo isset($course_error) ? 'red' : 'green'; ?>; max-width: 600px; margin: 1rem auto; padding: 0.75rem; border-radius: 5px; text-align: center; font-weight: bold;"><?php echo $course_message; ?></p>
      <?php endif; ?>

      <section class="form-section" style="max-width: 600px; margin: 2rem auto; padding: 1.5rem; background: #f0f0f0; border-radius: 10px;">
        <h2>📝 Register a New Course</h2>
        <form action="index.php" method="POST">
          <input type="hidden" name="action" value="create_course"> 
          
          <label style="font-weight: bold;">Course Name:</label><br>
          <input type="text" name="courseName" required style="width: 100%; padding: 0.5rem; margin-bottom: 1rem; border: 1px solid #ccc; border-radius: 5px;"><br>

          <label style="font-weight: bold;">Description:</label><br>
          <textarea name="description" required style="width: 100%; padding: 0.5rem; margin-bottom: 1.5rem; border: 1px solid #ccc; border-radius: 5px;"></textarea><br>

          <button type="submit" style="width: 100%; background-color: #2b6cb0; color: white; border: none; padding: 0.75rem; border-radius: 5px; cursor: pointer;">
            Save Course
          </button>
        </form>
      </section>

      <hr style="max-width: 90%; margin: 3rem auto; border-top: 1px dashed #ccc;">

      <section style="max-width: 900px; margin: 2rem auto;">
        <h2>🔔 Pending Join Requests (for your courses)</h2>
        <?php if (isset($request_message)): ?>
          <p style="color: white; background-color: <?php echo isset($request_error) ? 'red' : 'green'; ?>; padding: 0.75rem; border-radius: 5px; margin-bottom: 1rem; text-align: center; font-weight: bold;"><?php echo $request_message; ?></p>
        <?php endif; ?>
        
        <?php $requests = get_pending_requests_for_faculty($userId); ?>
        
        <?php if (empty($requests)): ?>
          <p style="padding: 1rem; background-color: #f0f0f0; border-radius: 5px; text-align: center;">No new pending requests right now. Time to relax! 😎</p>
        <?php else: ?>
          <table border="1" cellpadding="10" width="100%" style="border-collapse: collapse; text-align: left;">
            <thead>
              <tr style="background-color: #2b6cb0; color: white;">
                <th>Course Title</th>
                <th>Student Username</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($requests as $req): ?>
              <tr>
                <td><?php echo htmlspecialchars($req['course_title']); ?></td>
                <td><?php echo htmlspecialchars($req['student_username']); ?></td>
                <td>
                  <form action="index.php" method="POST" style="display: inline-block;">
                    <input type="hidden" name="action" value="approve">
                    <input type="hidden" name="course_id" value="<?php echo $req['course_id']; ?>">
                    <input type="hidden" name="student_id" value="<?php echo $req['student_id']; ?>">
                    <button type="submit" style="background-color: green; color: white; border: none; padding: 0.3rem 0.6rem; border-radius: 5px; cursor: pointer; margin-right: 0.5rem;">Approve</button>
                  </form>
                  <form action="index.php" method="POST" style="display: inline-block;">
                    <input type="hidden" name="action" value="reject">
                    <input type="hidden" name="course_id" value="<?php echo $req['course_id']; ?>">
                    <input type="hidden" name="student_id" value="<?php echo $req['student_id']; ?>">
                    <button type="submit" style="background-color: red; color: white; border: none; padding: 0.3rem 0.6rem; border-radius: 5px; cursor: pointer;">Reject</button>
                  </form>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </section>

    <?php elseif ($role === 'student'): ?>
      
      <h2 style="text-align: center; color: #2b6cb0; margin-bottom: 1rem;">Course Enrollment Portal</h2>

      <?php if (isset($join_message)): ?>
          <p style="color: white; background-color: <?php echo isset($join_error) ? 'red' : 'green'; ?>; max-width: 900px; margin: 1rem auto; padding: 0.75rem; border-radius: 5px; text-align: center; font-weight: bold;"><?php echo $join_message; ?></p>
      <?php endif; ?>

      <section style="max-width: 900px; margin: 2rem auto;">
        <h2>📚 My Enrolled Courses</h2>
        <?php $enrolled_courses = get_student_enrolled_courses($userId); ?>
        <?php if (empty($enrolled_courses)): ?>
          <p style="padding: 1rem; background-color: #f0f0f0; border-radius: 5px; text-align: center;">You are not enrolled in any courses yet. Go join one below!</p>
        <?php else: ?>
          <div class="course-grid">
            <?php foreach ($enrolled_courses as $course): ?>
              <div class="course-card" style="background: lightgreen;">
                <h3><?php echo htmlspecialchars($course['title']); ?> (Enrolled)</h3>
                <p><?php echo htmlspecialchars($course['description']); ?></p>
                <button style="background-color: #38a169;">Access Course</button>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </section>
      
      <hr style="max-width: 90%; margin: 3rem auto; border-top: 1px dashed #ccc;">

      <section style="max-width: 900px; margin: 2rem auto;">
        <h2>🌍 All Available Courses</h2>
        <div class="course-grid">
          <?php 
          $all_courses = get_all_courses(); 
          // Filter out courses the student is already enrolled in
          $enrolled_ids = array_column($enrolled_courses, 'id');
          
          // I needed to get all the current pending requests so we don't show those courses again
          // I will look for requests where *this* student is the requester
          $pdo = db_connect();
          $stmt_pending = $pdo->prepare("SELECT course_id FROM enrollment_requests WHERE student_id = ?");
          $stmt_pending->execute([$userId]);
          $pending_course_ids = array_column($stmt_pending->fetchAll(), 'course_id');

          $joinable_courses = array_filter($all_courses, 
            fn($c) => !in_array($c['id'], $enrolled_ids) && !in_array($c['id'], $pending_course_ids)
          );
          ?>

          <?php if (empty($joinable_courses)): ?>
            <p style="padding: 1rem; background-color: #f0f0f0; border-radius: 5px; text-align: center;">No more courses available to join right now!</p>
          <?php else: ?>
            <?php foreach ($joinable_courses as $course): ?>
            <div class="course-card">
              <h3><?php echo htmlspecialchars($course['title']); ?></h3>
              <p><?php echo htmlspecialchars($course['description']); ?></p>
              
              <form action="index.php" method="POST">
                <input type="hidden" name="action" value="join_course">
                <input type="hidden" name="course_id" value="<?php echo $course['id']; ?>">
                <button type="submit" class="join-btn">Request to Join</button>
              </form>
            </div>
            <?php endforeach; ?>
          <?php endif; ?>

        </div>
      </section>
      
    <?php endif; ?>

  </main>
</body>
</html>