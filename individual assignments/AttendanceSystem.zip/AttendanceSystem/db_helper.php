<?php
// This file is now talking to a REAL database using PDO, I was struggling to do this so I got help because I was genuienly stuck
// 
require_once 'db_config.php'; // To Grab the connection details


/**
 * Finds a user by their username using a secure prepared statement. 
 */
function find_user_by_username($username) {
    $pdo = db_connect();
    // Using ? as a placeholder prevents SQL Injection (SECURITY: 4.b)
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    // fetch() returns the single row or false
    return $stmt->fetch(); 
}

/**
 * Finds a user by their ID.
 */
function find_user_by_id($id) {
    $pdo = db_connect();
    $stmt = $pdo->prepare("SELECT id, username, role FROM users WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/**
 * Adds a new user to the database with a securely hashed password. 
 
 */
function create_user($username, $password, $role) {
    $pdo = db_connect();
    
    // to hash the password
    $password_hash = password_hash($password, PASSWORD_BCRYPT); 

    $sql = "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    
    // Execute the prepared statement
    return $stmt->execute([$username, $password_hash, $role]);
}

/**
 * Saves a new course created by a faculty member.
 */
function create_course($title, $description, $instructor_id) {
    $pdo = db_connect();
    $sql = "INSERT INTO courses (title, description, instructor_id) VALUES (?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute([$title, $description, $instructor_id]);
}

/**
 * Gets all courses for the student view.
 */
function get_all_courses() {
    $pdo = db_connect();
    $stmt = $pdo->query("SELECT * FROM courses ORDER BY title ASC");
    return $stmt->fetchAll();
}

/**
 * Gets all pending requests for a faculty's courses. 
 */
function get_pending_requests_for_faculty($faculty_id) {
    $pdo = db_connect();
    
    // Complex SQL query to join requests, courses (to filter by instructor_id), and users
    $sql = "
        SELECT 
            er.course_id, 
            er.student_id,
            u.username AS student_username, 
            c.title AS course_title
        FROM enrollment_requests er
        JOIN courses c ON er.course_id = c.id
        JOIN users u ON er.student_id = u.id
        WHERE c.instructor_id = ?
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$faculty_id]);
    
    return $stmt->fetchAll();
}

/**
 * Processes an enrollment request (approve or reject). (2.b)
 */
function process_request($course_id, $student_id, $action) {
    $pdo = db_connect();
    
    // Start a transaction to ensure both operations succeed or fail together
    $pdo->beginTransaction(); 
    
    try {
        if ($action === 'approve') {
            // 1. If approved, add it to the final enrollments list
            $sql_insert = "INSERT INTO enrollments (course_id, student_id) VALUES (?, ?)";
            $stmt_insert = $pdo->prepare($sql_insert);
            $stmt_insert->execute([$course_id, $student_id]);
        } 
        
        // 2. In both cases (approve or reject), removing the request from the pending list
        $sql_delete = "DELETE FROM enrollment_requests WHERE course_id = ? AND student_id = ?";
        $stmt_delete = $pdo->prepare($sql_delete);
        $stmt_delete->execute([$course_id, $student_id]);
        
        // If everything worked, save the changes
        $pdo->commit();
        return true;
        
    } catch (\Exception $e) {
        // If anything failed, undo all changes
        $pdo->rollBack();
        \
        return false;
    }
}

/**
 * Saves a student's request to join a course. (3.a)
 */
function create_join_request($course_id, $student_id) {
    $pdo = db_connect();
    
    // Safety check: is there already an enrollment for this student/course?
    $sql_check_enrollment = "SELECT 1 FROM enrollments WHERE course_id = ? AND student_id = ?";
    $stmt_check_enrollment = $pdo->prepare($sql_check_enrollment);
    $stmt_check_enrollment->execute([$course_id, $student_id]);
    
    if ($stmt_check_enrollment->fetch()) {
        return false; // Already enrolled
    }

    // Safety check: is there already a pending request?
    $sql_check_request = "SELECT 1 FROM enrollment_requests WHERE course_id = ? AND student_id = ?";
    $stmt_check_request = $pdo->prepare($sql_check_request);
    $stmt_check_request->execute([$course_id, $student_id]);
    
    if ($stmt_check_request->fetch()) {
        return false; // Already requested
    }

    // Insert the new request
    $sql_insert = "INSERT INTO enrollment_requests (course_id, student_id) VALUES (?, ?)";
    $stmt_insert = $pdo->prepare($sql_insert);
    return $stmt_insert->execute([$course_id, $student_id]);
}

/**
 * Gets a list of courses a student is enrolled in. 
 */
function get_student_enrolled_courses($student_id) {
    $pdo = db_connect();
    
    // Join the enrollments table with the courses table
    $sql = "
        SELECT c.* FROM courses c
        JOIN enrollments e ON c.id = e.course_id
        WHERE e.student_id = ?
        ORDER BY c.title ASC
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$student_id]);
    
    return $stmt->fetchAll();
}
?>