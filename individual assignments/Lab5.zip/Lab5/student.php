<?php
// student.php
$userId = $_SESSION['user_id'];
$username = $_SESSION['username'];

$join_message = $attendance_message = '';
$join_error = $attendance_error = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Join course
    if (isset($_POST['action']) && $_POST['action'] === 'join_course') {
        $course_id = $_POST['course_id'] ?? '';
        if (create_join_request($course_id, $userId)) {
            $join_message = "Join request sent successfully!";
        } else {
            $join_message = "You have already requested or enrolled in this course!";
            $join_error = true;
        }
    }

    // Mark attendance via code
    if (isset($_POST['action']) && $_POST['action'] === 'mark_attendance') {
        $code = strtoupper(trim($_POST['attendance_code'] ?? ''));
        if (mark_attendance_by_code($userId, $code)) {
            $attendance_message = "Attendance marked successfully!";
        } else {
            $attendance_message = "Invalid code or attendance already marked.";
            $attendance_error = true;
        }
    }
}

// Fetch student enrolled courses
$enrolled_courses = get_student_enrolled_courses($userId);
$all_courses = get_all_courses();
$attendance_report = get_student_attendance_report($userId);
?>

<div class="dashboard-container">
    <h1 class="dashboard-title">Student Dashboard</h1>
    <p style="text-align: center; color: #666; margin-bottom: 2rem;">Welcome, <?php echo htmlspecialchars($username); ?>!</p>

    <!-- Messages -->
    <?php if($join_message): ?>
        <div class="message <?php echo $join_error ? 'error' : 'success'; ?>">
            <?php echo $join_message; ?>
        </div>
    <?php endif; ?>
    
    <?php if($attendance_message): ?>
        <div class="message <?php echo $attendance_error ? 'error' : 'success'; ?>">
            <?php echo $attendance_message; ?>
        </div>
    <?php endif; ?>

    <!-- Mark Attendance Section -->
    <section class="dashboard-section highlight-section">
        <h2>Mark Attendance</h2>
        <form method="POST" class="form-styled">
            <input type="hidden" name="action" value="mark_attendance">
            <div class="form-group">
                <label for="attendance_code">Enter Attendance Code:</label>
                <input type="text" id="attendance_code" name="attendance_code" required 
                       placeholder="Enter 6-character code" style="text-transform: uppercase;">
            </div>
            <button type="submit" class="btn btn-primary">Mark Attendance</button>
        </form>
    </section>

    <!-- My Enrolled Courses Section -->
    <section class="dashboard-section">
        <h2>My Enrolled Courses</h2>
        <?php if(empty($enrolled_courses)): ?>
            <p class="no-data">You are not enrolled in any courses yet. Browse courses below to join!</p>
        <?php else: ?>
            <div class="course-grid">
                <?php foreach($enrolled_courses as $c): ?>
                    <div class="course-card enrolled">
                        <h3><?php echo htmlspecialchars($c['title']); ?></h3>
                        <p><?php echo htmlspecialchars($c['description']); ?></p>
                        <span class="badge">Enrolled</span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- Available Courses Section -->
    <section class="dashboard-section">
        <h2>Available Courses</h2>
        <?php if(empty($all_courses)): ?>
            <p class="no-data">No courses available at the moment.</p>
        <?php else: ?>
            <div class="course-grid">
                <?php 
                $enrolled_ids = array_column($enrolled_courses, 'id');
                foreach($all_courses as $c): 
                    $is_enrolled = in_array($c['id'], $enrolled_ids);
                ?>
                    <div class="course-card">
                        <h3><?php echo htmlspecialchars($c['title']); ?></h3>
                        <p><?php echo htmlspecialchars($c['description']); ?></p>
                        <?php if($is_enrolled): ?>
                            <button class="btn btn-disabled" disabled>Already Enrolled</button>
                        <?php else: ?>
                            <form method="POST">
                                <input type="hidden" name="action" value="join_course">
                                <input type="hidden" name="course_id" value="<?php echo $c['id']; ?>">
                                <button type="submit" class="btn btn-secondary">Request to Join</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- Attendance Report Section -->
    <section class="dashboard-section">
        <h2>My Attendance Report</h2>
        <?php if(empty($attendance_report)): ?>
            <p class="no-data">No attendance recorded yet.</p>
        <?php else: ?>
            <table class="styled-table">
                <thead>
                    <tr>
                        <th>Course</th>
                        <th>Sessions Attended</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($attendance_report as $r): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($r['course_title']); ?></td>
                            <td><strong><?php echo $r['attended']; ?></strong></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </section>
</div>