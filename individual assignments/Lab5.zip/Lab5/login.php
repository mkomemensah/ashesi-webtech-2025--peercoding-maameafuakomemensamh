<?php
// Start the session to manage the user's logged-in state
session_start();
require_once 'db_helper.php';

// If the user is already logged in, I can send them to the main dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$error = '';

// Check if the form was submitted using POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //  Server-side validation
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? ''; 

    if (empty($username) || empty($password)) {
        $error = "Whoops! Both username and password are required.";
    } else {
        // Find the user
        $user = find_user_by_username($username);

        // Check if the user exists AND the password is correct against the hash (4.a)
        if ($user && password_verify($password, $user['password_hash'])) {
            // Success! Store user info in the session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            
            // Redirect to the protected dashboard!
            header('Location: index.php');
            exit;
        } else {
            $error = "That username or password looks incorrect. Try again!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>SmartRegister – Login</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <nav>
    <div class="logo">SmartRegister</div>
    <div class="nav-links">
      <a href="register.php">Register</a>
    </div>
  </nav>

  <main>
    <h1 class="dashboard-title">Welcome Back! Login</h1>
    
    <section class="form-section" style="max-width: 400px; margin: 2rem auto; padding: 1.5rem; background: #f0f0f0; border-radius: 10px;">
      
      <?php if ($error): ?>
        <p style="color: red; margin-bottom: 1rem; text-align: center; font-weight: bold;"><?php echo $error; ?></p>
      <?php endif; ?>

      <form action="login.php" method="POST">
        <label for="username" style="font-weight: bold;">Username:</label><br>
        <input type="text" id="username" name="username" required 
               style="width: 100%; padding: 0.5rem; margin-bottom: 1rem; border: 1px solid #ccc; border-radius: 5px;"><br>

        <label for="password" style="font-weight: bold;">Password:</label><br>
        <input type="password" id="password" name="password" required 
               style="width: 100%; padding: 0.5rem; margin-bottom: 1.5rem; border: 1px solid #ccc; border-radius: 5px;"><br>

        <button type="submit" style="width: 100%; background-color: #2b6cb0; color: white; border: none; padding: 0.75rem; border-radius: 5px; cursor: pointer;">
          Log In
        </button>
      </form>
      <p style="margin-top: 1rem; text-align: center;">New User? <a href="register.php" style="color: #2b6cb0; text-decoration: none; font-weight: bold;">Register Here</a></p>
    </section>
  </main>
</body>
</html>