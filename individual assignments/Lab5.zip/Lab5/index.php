<?php
session_start();
require_once 'db_helper.php';

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Choose dashboard based on role
$role = $_SESSION['role'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - SmartRegister</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<nav>
    <div class="logo">SmartRegister</div>
    <div class="nav-links">
        <a href="logout.php">Logout</a>
    </div>
</nav>

<main>
<?php
if ($role === 'faculty') {
    include 'faculty.php';
} elseif ($role === 'student') {
    include 'student.php';
} else {
    echo "<p>Unknown role!</p>";
}
?>
</main>
</body>
</html>