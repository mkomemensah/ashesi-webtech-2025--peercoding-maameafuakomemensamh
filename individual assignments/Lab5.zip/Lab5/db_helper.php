<?php
// db_helper.php
// Database connection and helper functions

// Connect to the database
function db_connect() {
    $host = 'localhost';
    $db   = 'test';
    $user = 'root';
    $pass = '';
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $pdo = new PDO($dsn, $user, $pass, $options);
        return $pdo;
    } catch (\PDOException $e) {
        throw new \PDOException($e->getMessage(), (int)$e->getCode());
    }
}

// ----------------------- USER FUNCTIONS -----------------------

// Find user by username
function find_user_by_username($username) {
    $pdo = db_connect();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    return $stmt->fetch();
}

// Create a new user
function create_user($username, $password, $role) {
    $pdo = db_connect();
    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $sql = "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute([$username, $hashed, $role]);
}

// Register a new user (alternative name)
function register_user($username, $password, $role) {
    return create_user($username, $password, $role);
}

// Login user
function login_user($username, $password) {
    $pdo = db_connect();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username=?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password_hash'])) {
        return $user;
    }
    return false;
}

// ----------------------- COURSE FUNCTIONS -----------------------

// Create a course
function create_course($title, $description, $instructor_id) {
    $pdo = db_connect();
    $sql = "INSERT INTO courses (title, description, instructor_id) VALUES (?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute([$title, $description, $instructor_id]);
}

// Get all courses
function get_all_courses() {
    $pdo = db_connect();
    $stmt = $pdo->query("SELECT * FROM courses");
    return $stmt->fetchAll();
}

// Get courses a faculty teaches
function get_faculty_courses($faculty_id) {
    $pdo = db_connect();
    $stmt = $pdo->prepare("SELECT * FROM courses WHERE instructor_id=?");
    $stmt->execute([$faculty_id]);
    return $stmt->fetchAll();
}

// Get courses a student is enrolled in
function get_student_enrolled_courses($student_id) {
    $pdo = db_connect();
    $sql = "SELECT c.* FROM courses c
            JOIN enrollments e ON c.id = e.course_id
            WHERE e.student_id=?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$student_id]);
    return $stmt->fetchAll();
}

// ----------------------- ENROLLMENT / REQUESTS -----------------------

// Student requests to join a course
function create_join_request($course_id, $student_id) {
    $pdo = db_connect();
    // Check if already requested or enrolled
    $stmt = $pdo->prepare("SELECT 1 FROM enrollments WHERE course_id=? AND student_id=?");
    $stmt->execute([$course_id, $student_id]);
    if($stmt->fetch()) return false;

    $stmt2 = $pdo->prepare("SELECT 1 FROM join_requests WHERE course_id=? AND student_id=?");
    $stmt2->execute([$course_id, $student_id]);
    if($stmt2->fetch()) return false;

    $stmt3 = $pdo->prepare("INSERT INTO join_requests (course_id, student_id) VALUES (?, ?)");
    return $stmt3->execute([$course_id, $student_id]);
}

// Get pending requests for a faculty
function get_pending_requests_for_faculty($faculty_id) {
    $pdo = db_connect();
    $sql = "SELECT jr.*, u.username AS student_username, c.title AS course_title, c.id AS course_id, u.id AS student_id
            FROM join_requests jr
            JOIN users u ON jr.student_id = u.id
            JOIN courses c ON jr.course_id = c.id
            WHERE c.instructor_id=?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$faculty_id]);
    return $stmt->fetchAll();
}

// Approve or reject a join request
function process_request($course_id, $student_id, $action) {
    $pdo = db_connect();
    if($action === 'approve') {
        $stmt = $pdo->prepare("INSERT INTO enrollments (course_id, student_id) VALUES (?, ?)");
        $stmt->execute([$course_id, $student_id]);
    }
    $del = $pdo->prepare("DELETE FROM join_requests WHERE course_id=? AND student_id=?");
    return $del->execute([$course_id, $student_id]);
}

// ----------------------- ATTENDANCE FUNCTIONS -----------------------

// Create attendance session
function create_attendance_session($course_id, $code) {
    $pdo = db_connect();
    $sql = "INSERT INTO attendance_sessions (course_id, code) VALUES (?, ?)";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute([$course_id, $code]);
}

// Mark attendance by session id
function mark_attendance($session_id, $student_id) {
    $pdo = db_connect();
    $check = $pdo->prepare("SELECT 1 FROM attendance_records WHERE session_id=? AND student_id=?");
    $check->execute([$session_id, $student_id]);
    if($check->fetch()) return false;

    $sql = "INSERT INTO attendance_records (session_id, student_id) VALUES (?, ?)";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute([$session_id, $student_id]);
}

// Mark attendance by code (student side)
function mark_attendance_by_code($student_id, $code) {
    $pdo = db_connect();
    $stmt = $pdo->prepare("SELECT id FROM attendance_sessions WHERE code=?");
    $stmt->execute([$code]);
    $session = $stmt->fetch();
    if(!$session) return false;
    return mark_attendance($session['id'], $student_id);
}

// Get faculty's attendance sessions
function get_faculty_attendance_sessions($faculty_id) {
    $pdo = db_connect();
    $sql = "SELECT s.*, c.title AS course_title 
            FROM attendance_sessions s
            JOIN courses c ON s.course_id = c.id
            WHERE c.instructor_id=?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$faculty_id]);
    return $stmt->fetchAll();
}

// Get student attendance report
function get_student_attendance_report($student_id) {
    $pdo = db_connect();
    $sql = "SELECT c.title AS course_title, COUNT(ar.id) AS attended
            FROM attendance_records ar
            JOIN attendance_sessions s ON ar.session_id = s.id
            JOIN courses c ON s.course_id = c.id
            WHERE ar.student_id = ?
            GROUP BY c.id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$student_id]);
    return $stmt->fetchAll();
}

?>