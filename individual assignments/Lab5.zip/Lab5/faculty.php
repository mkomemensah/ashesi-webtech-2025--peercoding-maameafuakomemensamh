<?php
// faculty.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$userId = $_SESSION['user_id'];
$username = $_SESSION['username'];

$course_message = $request_message = $attendance_message = '';
$course_error = $request_error = $attendance_error = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // CREATE COURSE
    if (isset($_POST['action']) && $_POST['action'] === 'create_course') {
        $courseName = trim($_POST['courseName'] ?? '');
        $description = trim($_POST['description'] ?? '');
        if (empty($courseName) || empty($description)) {
            $course_message = "Course name and description required!";
            $course_error = true;
        } else {
            if (create_course($courseName, $description, $userId)) {
                $course_message = "Course '{$courseName}' created successfully!";
            } else {
                $course_message = "Error creating course.";
                $course_error = true;
            }
        }
    }

    // PROCESS JOIN REQUEST
    if (isset($_POST['action']) && in_array($_POST['action'], ['approve', 'reject'])) {
        $course_id = $_POST['course_id'] ?? '';
        $student_id = $_POST['student_id'] ?? '';
        if (process_request($course_id, $student_id, $_POST['action'])) {
            $request_message = "Request " . $_POST['action'] . "d successfully!";
        } else {
            $request_message = "Error processing request.";
            $request_error = true;
        }
    }

    // CREATE ATTENDANCE SESSION
    if (isset($_POST['action']) && $_POST['action'] === 'create_session') {
        $course_id = $_POST['course_id'] ?? '';
        $code = strtoupper(bin2hex(random_bytes(3))); // simple 6-char code
        if (create_attendance_session($course_id, $code)) {
            $attendance_message = "Attendance session created. Code: <strong>$code</strong>";
        } else {
            $attendance_message = "Error creating session.";
            $attendance_error = true;
        }
    }
}

// Get faculty courses and pending requests
$courses = get_faculty_courses($userId);
$requests = get_pending_requests_for_faculty($userId);
$sessions = get_faculty_attendance_sessions($userId);
?>

<div class="dashboard-container">
    <h1 class="dashboard-title">Faculty Dashboard</h1>
    <p style="text-align: center; color: #666; margin-bottom: 2rem;">Welcome, <?php echo htmlspecialchars($username); ?>!</p>

    <!-- Messages -->
    <?php if($course_message): ?>
        <div class="message <?php echo $course_error ? 'error' : 'success'; ?>">
            <?php echo $course_message; ?>
        </div>
    <?php endif; ?>
    
    <?php if($request_message): ?>
        <div class="message <?php echo $request_error ? 'error' : 'success'; ?>">
            <?php echo $request_message; ?>
        </div>
    <?php endif; ?>
    
    <?php if($attendance_message): ?>
        <div class="message <?php echo $attendance_error ? 'error' : 'success'; ?>">
            <?php echo $attendance_message; ?>
        </div>
    <?php endif; ?>

    <!-- Create Course Section -->
    <section class="dashboard-section">
        <h2>Create New Course</h2>
        <form method="POST" class="form-styled">
            <input type="hidden" name="action" value="create_course">
            <div class="form-group">
                <label for="courseName">Course Name:</label>
                <input type="text" id="courseName" name="courseName" required>
            </div>
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea id="description" name="description" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Create Course</button>
        </form>
    </section>

    <!-- My Courses Section -->
    <section class="dashboard-section">
        <h2>My Courses</h2>
        <?php if(empty($courses)): ?>
            <p class="no-data">You haven't created any courses yet.</p>
        <?php else: ?>
            <div class="course-grid">
                <?php foreach($courses as $course): ?>
                    <div class="course-card">
                        <h3><?php echo htmlspecialchars($course['title']); ?></h3>
                        <p><?php echo htmlspecialchars($course['description']); ?></p>
                        <form method="POST" style="margin-top: 1rem;">
                            <input type="hidden" name="action" value="create_session">
                            <input type="hidden" name="course_id" value="<?php echo $course['id']; ?>">
                            <button type="submit" class="btn btn-secondary">Create Attendance Session</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- Pending Join Requests Section -->
    <section class="dashboard-section">
        <h2>Pending Join Requests</h2>
        <?php if(empty($requests)): ?>
            <p class="no-data">No pending requests.</p>
        <?php else: ?>
            <div class="requests-container">
                <?php foreach($requests as $req): ?>
                    <div class="request-card">
                        <p><strong><?php echo htmlspecialchars($req['student_username']); ?></strong> wants to join <strong><?php echo htmlspecialchars($req['course_title']); ?></strong></p>
                        <div class="request-actions">
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="action" value="approve">
                                <input type="hidden" name="course_id" value="<?php echo $req['course_id']; ?>">
                                <input type="hidden" name="student_id" value="<?php echo $req['student_id']; ?>">
                                <button type="submit" class="btn btn-approve">Approve</button>
                            </form>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="action" value="reject">
                                <input type="hidden" name="course_id" value="<?php echo $req['course_id']; ?>">
                                <input type="hidden" name="student_id" value="<?php echo $req['student_id']; ?>">
                                <button type="submit" class="btn btn-reject">Reject</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- Attendance Sessions Section -->
    <section class="dashboard-section">
        <h2>Attendance Sessions</h2>
        <?php if(empty($sessions)): ?>
            <p class="no-data">No attendance sessions created yet.</p>
        <?php else: ?>
            <table class="styled-table">
                <thead>
                    <tr>
                        <th>Session ID</th>
                        <th>Course</th>
                        <th>Access Code</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($sessions as $s): ?>
                        <tr>
                            <td><?php echo $s['id']; ?></td>
                            <td><?php echo htmlspecialchars($s['course_title']); ?></td>
                            <td><strong class="code"><?php echo $s['code']; ?></strong></td>
                            <td><?php echo $s['created_at']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </section>
</div>