// ===================== DASHBOARD COURSE CARDS =====================
// This script creates the course cards and adds them to the page.

// Step 1: Get the "courseGrid" section from the HTML file.
const courseGrid = document.getElementById("courseGrid");

// Step 2: Create a list (array) of courses.
const courses = [
  {
    title: "Introduction to Programming",
    description: "Learn the basics of Python and logical thinking.",
  },
  {
    title: "Database Systems",
    description: "Understand how databases store and manage information.",
  },
  {
    title: "Web Development",
    description: "Design and build interactive web pages with HTML, CSS, and JS.",
  },
  {
    title: "Leadership Seminar",
    description: "Develop leadership and teamwork skills for real-world impact.",
  },
];

// Step 3: Loop through each course and create a card.
courses.forEach((course) => {
  // Create the outer card container
  const card = document.createElement("div");
  card.classList.add("course-card");

  // Add course title
  const title = document.createElement("h3");
  title.textContent = course.title;

  // Add course description
  const desc = document.createElement("p");
  desc.textContent = course.description;

  // Create the "Join as Observer" button
  const button = document.createElement("button");
  button.textContent = "Join as Observer";

  // Add a simple action when button is clicked
  button.addEventListener("click", () => {
    alert(`You have joined "${course.title}" as an observer.`);
  });

  // Add all parts to the card
  card.appendChild(title);
  card.appendChild(desc);
  card.appendChild(button);

  // Finally, add the card to the main grid on the page
  courseGrid.appendChild(card);
});
