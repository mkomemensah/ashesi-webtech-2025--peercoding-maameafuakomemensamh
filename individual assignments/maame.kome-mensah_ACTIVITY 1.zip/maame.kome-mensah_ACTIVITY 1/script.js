/* ============================================================
   ASHESI ATTENDANCE PORTAL SCRIPT (BEGINNER-FRIENDLY)
   - Handles form switching (Login / Register)
   - Basic form validation using JavaScript
   - Simulated “database variables” (no backend)
   ============================================================ */

/* -------- SWITCHING BETWEEN FORMS -------- */
const loginTab = document.getElementById("loginTab");
const registerTab = document.getElementById("registerTab");

const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");

loginTab.addEventListener("click", () => {
    loginTab.classList.add("active");
    registerTab.classList.remove("active");
    loginForm.style.display = "block";
    registerForm.style.display = "none";
});

registerTab.addEventListener("click", () => {
    registerTab.classList.add("active");
    loginTab.classList.remove("active");
    registerForm.style.display = "block";
    loginForm.style.display = "none";
});

/* -------- SIMULATED DATABASE -------- */
// These are example variables that could come from a real database later
let storedEmail = "student@ashesi.edu.gh";
let storedPassword = "ashesi123";

/* -------- LOGIN VALIDATION -------- */
loginForm.addEventListener("submit", function(event) {
    event.preventDefault(); // Stop the page from reloading

    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;
    const errorText = document.getElementById("loginError");

    if (email === "" || password === "") {
        errorText.textContent = "Please fill in all fields.";
    } else if (email !== storedEmail || password !== storedPassword) {
        errorText.textContent = "Incorrect email or password.";
    } else {
        errorText.style.color = "green";
        errorText.textContent = "Login successful!";
    }
});

/* -------- REGISTRATION VALIDATION -------- */
registerForm.addEventListener("submit", function(event) {
    event.preventDefault();

    const name = document.getElementById("regName").value;
    const email = document.getElementById("regEmail").value;
    const password = document.getElementById("regPassword").value;
    const role = document.getElementById("regRole").value;
    const errorText = document.getElementById("registerError");

    if (name === "" || email === "" || password === "" || role === "") {
        errorText.textContent = "Please complete all fields.";
        return;
    }

    if (password.length < 6) {
        errorText.textContent = "Password must be at least 6 characters long.";
        return;
    }

    // If everything is fine, simulate saving the data
    storedEmail = email;
    storedPassword = password;

    errorText.style.color = "green";
    errorText.textContent = "Registration successful! You can now log in.";
});
